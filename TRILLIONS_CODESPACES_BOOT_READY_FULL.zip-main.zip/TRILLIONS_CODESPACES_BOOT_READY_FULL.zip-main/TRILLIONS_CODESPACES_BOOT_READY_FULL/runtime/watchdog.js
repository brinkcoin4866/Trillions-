module.exports = () => process.memoryUsage();
